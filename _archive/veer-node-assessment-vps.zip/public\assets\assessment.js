'use strict';

const state = {
  active: false,
  submitting: false,
  question: null,
  current: 0,
  total: 35,
  answered: 0,
  selected: new Set(),
  deadline: 0,
  timerId: null,
  warningShown: false,
};

const elements = {};

document.addEventListener('DOMContentLoaded', () => {
  for (const id of [
    'introScreen', 'assessmentScreen', 'systemState', 'startForm',
    'termsAccepted', 'startButton', 'startError', 'questionNumber', 'questionCategory', 'answeredLabel',
    'progressBar', 'questionCard', 'questionType', 'questionText', 'selectionHelp', 'questionImageWrap',
    'questionImage', 'optionsFieldset', 'optionsList', 'questionError', 'nextButton', 'nextButtonLabel',
    'timerRing', 'timerText', 'timerStatus', 'timerProgress', 'warningDialog', 'warningClose',
    'stateTitle', 'stateText'
  ]) elements[id] = document.getElementById(id);

  elements.startForm.addEventListener('submit', startAssessment);
  elements.nextButton.addEventListener('click', submitCurrentAnswer);
  elements.warningClose.addEventListener('click', () => elements.warningDialog.close());
  window.addEventListener('beforeunload', (event) => {
    if (state.active && !state.submitting) {
      event.preventDefault();
      event.returnValue = '';
    }
  });
  if (document.body.dataset.page === 'candidate-assessment') openOrStartAssessment();
  else restoreAttempt();
});

async function openOrStartAssessment() {
  try {
    const data = await request('/api/assessment/state');
    if (data.completed) {
      window.location.replace('/assessment-result.html');
      return;
    }
    beginClientSession(data);
  } catch (error) {
    if (error.status !== 401) {
      showLaunchError(error.message);
      return;
    }
    const candidate = { ...getCandidateFromStepTwo(), accepted: true };
    if (!candidate.name || !candidate.email) {
      showLaunchError('Your Step 2 candidate details could not be found. Please return to Step 2 and continue again.');
      return;
    }
    try {
      const data = await request('/api/assessment/start', { method: 'POST', body: JSON.stringify(candidate) });
      beginClientSession(data);
    } catch (startError) {
      showLaunchError(startError.message);
    }
  }
}

function showLaunchError(message) {
  elements.introScreen.classList.add('hidden');
  elements.assessmentScreen.classList.add('hidden');
  elements.systemState.classList.remove('hidden');
  elements.stateTitle.textContent = 'Assessment could not start';
  elements.stateText.textContent = message;
}

function getCandidateFromStepTwo() {
  const params = new URLSearchParams(window.location.search);
  let candidate = {
    name: String(params.get('name') || `${params.get('first') || ''} ${params.get('last') || ''}`).trim(),
    email: String(params.get('email') || '').trim(),
  };
  try {
    const saved = JSON.parse(sessionStorage.getItem('veerCandidate') || 'null');
    if (!candidate.name && saved?.name) candidate.name = saved.name;
    if (!candidate.name && (saved?.first || saved?.last)) candidate.name = `${saved.first || ''} ${saved.last || ''}`.trim();
    if (!candidate.email && saved?.email) candidate.email = saved.email;
  } catch { /* Ignore malformed optional prefill data. */ }
  return candidate;
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'The assessment service could not complete this request.');
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

async function restoreAttempt() {
  try {
    const data = await request('/api/assessment/state');
    if (data.completed) {
      window.location.replace('/assessment-result.html');
      return;
    }
    beginClientSession(data);
  } catch (error) {
    if (error.status !== 401) elements.startError.textContent = error.message;
  }
}

async function startAssessment(event) {
  event.preventDefault();
  elements.startError.textContent = '';
  if (!elements.startForm.reportValidity()) return;
  elements.startButton.disabled = true;
  elements.startButton.querySelector('span').textContent = 'Preparing assessment…';
  try {
    const candidate = { ...getCandidateFromStepTwo(), accepted: elements.termsAccepted.checked };
    if (!candidate.name || !candidate.email) {
      throw new Error('Your Step 2 candidate details could not be found. Please return to Step 2 and continue to the assessment again.');
    }
    const data = await request('/api/assessment/start', { method: 'POST', body: JSON.stringify(candidate) });
    beginClientSession(data);
  } catch (error) {
    if (error.data?.availableAt) {
      const available = new Intl.DateTimeFormat(undefined, { dateStyle: 'long', timeStyle: 'short' }).format(new Date(error.data.availableAt));
      elements.startError.textContent = `${error.message} A new attempt is available from ${available}.`;
    } else elements.startError.textContent = error.message;
  } finally {
    elements.startButton.disabled = false;
    elements.startButton.querySelector('span').textContent = 'Begin assessment';
  }
}

function beginClientSession(data) {
  state.active = true;
  state.question = data.question;
  state.current = data.current;
  state.total = data.total;
  state.answered = Math.max(0, data.current - 1);
  state.deadline = Date.now() + data.remainingSeconds * 1000;
  state.warningShown = data.remainingSeconds < 300;
  elements.introScreen.classList.add('hidden');
  elements.systemState.classList.add('hidden');
  elements.assessmentScreen.classList.remove('hidden');
  renderQuestion();
  startTimer();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function renderQuestion() {
  const question = state.question;
  state.selected = new Set();
  elements.questionNumber.textContent = `Question ${state.current} of ${state.total}`;
  elements.questionCategory.textContent = question.category;
  elements.answeredLabel.textContent = `${state.answered} answered`;
  elements.timerProgress.textContent = `${state.current} / ${state.total}`;
  elements.progressBar.style.width = `${(state.answered / state.total) * 100}%`;
  elements.progressBar.parentElement.setAttribute('aria-valuenow', String(state.answered));
  elements.questionType.textContent = question.selectionCount === 1 ? 'Choose one answer' : `Choose exactly ${question.selectionCount}`;
  elements.questionText.textContent = question.question;
  elements.selectionHelp.textContent = question.selectionCount === 1
    ? 'Select one option to continue.'
    : `Select ${question.selectionCount} options. Partial credit may apply.`;
  elements.questionError.textContent = '';
  elements.nextButton.disabled = true;
  elements.nextButtonLabel.textContent = state.current === state.total ? 'Submit assessment' : 'Next question';

  if (question.image) {
    elements.questionImage.src = question.image;
    elements.questionImageWrap.classList.remove('hidden');
  } else {
    elements.questionImage.removeAttribute('src');
    elements.questionImageWrap.classList.add('hidden');
  }

  elements.optionsList.replaceChildren();
  question.options.forEach((option, index) => {
    const label = document.createElement('label');
    label.className = 'option-label';
    const input = document.createElement('input');
    input.type = question.selectionCount === 1 ? 'radio' : 'checkbox';
    input.name = 'answer';
    input.value = option.id;
    input.addEventListener('change', () => updateSelection(input));
    const key = document.createElement('span');
    key.className = 'option-key';
    key.textContent = String.fromCharCode(65 + index);
    const text = document.createElement('span');
    text.className = 'option-text';
    text.textContent = option.text;
    const indicator = document.createElement('span');
    indicator.className = 'option-indicator';
    indicator.setAttribute('aria-hidden', 'true');
    label.append(input, key, text, indicator);
    elements.optionsList.append(label);
  });
  elements.questionText.focus({ preventScroll: true });
}

function updateSelection(input) {
  const required = state.question.selectionCount;
  if (required === 1) {
    state.selected = new Set([input.value]);
  } else {
    if (input.checked && state.selected.size >= required) input.checked = false;
    if (input.checked) state.selected.add(input.value);
    else state.selected.delete(input.value);
  }
  elements.nextButton.disabled = state.selected.size !== required;
  elements.questionError.textContent = state.selected.size && state.selected.size < required
    ? `Select ${required - state.selected.size} more option${required - state.selected.size === 1 ? '' : 's'}.`
    : '';
}

async function submitCurrentAnswer() {
  if (state.submitting || elements.nextButton.disabled) return;
  state.submitting = true;
  elements.nextButton.disabled = true;
  elements.nextButtonLabel.textContent = state.current === state.total ? 'Submitting…' : 'Saving…';
  try {
    const data = await request('/api/assessment/answer', {
      method: 'POST',
      body: JSON.stringify({ questionId: state.question.id, answerIds: [...state.selected] }),
    });
    state.answered = state.current;
    if (data.readyToSubmit) {
      await finalizeAssessment(false);
      return;
    }
    state.question = data.question;
    state.current = data.current;
    state.deadline = Date.now() + data.remainingSeconds * 1000;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (error) {
    if (error.data?.completed) {
      window.location.replace('/assessment-result.html');
      return;
    }
    elements.questionError.textContent = error.message;
    elements.nextButton.disabled = false;
  } finally {
    state.submitting = false;
    if (state.active && state.current < state.total) elements.nextButtonLabel.textContent = 'Next question';
  }
}

function startTimer() {
  clearInterval(state.timerId);
  updateTimer();
  state.timerId = window.setInterval(updateTimer, 250);
}

function updateTimer() {
  const remaining = Math.max(0, Math.ceil((state.deadline - Date.now()) / 1000));
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  elements.timerText.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const percent = Math.max(0, (remaining / 2400) * 100);
  elements.timerRing.style.background = `conic-gradient(${remaining <= 300 ? 'var(--danger)' : 'var(--orange)'} ${percent}%, #e9e3dd 0)`;
  elements.timerRing.closest('.timer-panel').classList.toggle('warning', remaining <= 300);

  if (remaining <= 300) {
    elements.timerStatus.textContent = remaining === 300 ? 'Five minutes remain.' : 'Less than five minutes remain.';
    if (!state.warningShown) {
      state.warningShown = true;
      elements.warningDialog.showModal();
    }
  } else {
    elements.timerStatus.textContent = `${minutes} minute${minutes === 1 ? '' : 's'} remaining.`;
  }
  if (remaining === 0 && state.active && !state.submitting) finalizeAssessment(true);
}

async function finalizeAssessment(expired) {
  if (state.submitting && expired) return;
  state.submitting = true;
  state.active = false;
  clearInterval(state.timerId);
  if (elements.warningDialog.open) elements.warningDialog.close();
  elements.assessmentScreen.classList.add('hidden');
  elements.systemState.classList.remove('hidden');
  elements.stateTitle.textContent = expired ? 'Time has ended' : 'Assessing your responses';
  elements.stateText.textContent = expired
    ? 'Your assessment is locked. Submitted answers are being scored now.'
    : 'Please keep this page open while your submission is securely processed.';
  try {
    await request('/api/assessment/submit', { method: 'POST', body: JSON.stringify({ expired }) });
    window.location.replace('/assessment-result.html');
  } catch (error) {
    elements.stateTitle.textContent = 'Submission needs attention';
    elements.stateText.textContent = `${error.message} Please refresh this page to retrieve your recorded result.`;
  }
}
