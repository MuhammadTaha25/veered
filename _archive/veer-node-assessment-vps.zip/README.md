# VEER Node.js AI Assessment

## Run

Requires Node.js 20 or newer and no third-party packages.

```sh
npm start
```

The service listens on `PORT` (default `3000`). Open:

```text
http://localhost:3000/ai-skill-test.html
```

Point the website's **Candidate assessment** link to `/ai-skill-test.html`. After agreement, that page opens the dedicated timed experience at `/candidate-assessment.html`.

Step 2 should save the candidate identity before navigation:

```js
sessionStorage.setItem('veerCandidate', JSON.stringify({
  name: candidateName,
  email: candidateEmail
}));
window.location.href = '/ai-skill-test.html';
```

The assessment also accepts `name` and `email` query parameters for server-integrated navigation, but session storage avoids placing personal details in the URL.

## VPS deployment

1. Upload the complete folder.
2. Keep `private/veer_assessment_question_bank.json` outside any independently configured public/static directory.
3. Run the service under a process manager such as systemd or PM2.
4. Reverse-proxy the application through HTTPS with Nginx, Caddy, or the existing VPS proxy.
5. Ensure the Node process can write to `data/attempts.json`.
6. Back up the `data` directory or replace the file store with the site's database before using multiple Node instances.

## Security model

- The browser receives question text, shuffled options, and selection requirements only.
- Correct answers, rationales, scoring, random selection, expiry, and cooldown enforcement remain on the Node server.
- Attempts use an HttpOnly, SameSite cookie.
- POST requests are restricted to the same origin.
- Security headers and a restrictive Content Security Policy are included.
- The timer is server-authoritative and continues across refreshes.

## Assessment configuration

- Pool: 200 questions
- Attempt: 35 questions
- Duration: 40 minutes
- Selection mix: AI 21, ML 4, software development 4, aptitude 6
- Five-minute warning: `05:00`
- Navigation: forward only
- Cooldown: 7 days
- Pass: 80%+
- Fair pass: 70–79%
