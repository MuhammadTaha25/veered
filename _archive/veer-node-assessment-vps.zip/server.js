'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const BANK_PATH = path.join(ROOT, 'private', 'veer_assessment_question_bank.json');
const ATTEMPTS_PATH = process.env.ATTEMPTS_PATH || path.join(ROOT, 'data', 'attempts.json');
const PORT = Number(process.env.PORT || 3000);
const DURATION_SECONDS = 40 * 60;
const COOLDOWN_DAYS = 7;
const QUESTION_COUNT = 35;
const CATEGORY_QUOTAS = { AI: 21, ML: 4, 'Software development': 4, Aptitude: 6 };

const bankDocument = JSON.parse(fs.readFileSync(BANK_PATH, 'utf8'));
const questionsById = new Map(bankDocument.question_bank.map((question) => [question.id, question]));
let attempts = loadAttempts();
let writeQueue = Promise.resolve();

function loadAttempts() {
  try {
    const parsed = JSON.parse(fs.readFileSync(ATTEMPTS_PATH, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persistAttempts() {
  const snapshot = JSON.stringify(attempts, null, 2);
  const temporary = `${ATTEMPTS_PATH}.tmp`;
  writeQueue = writeQueue.then(async () => {
    await fs.promises.writeFile(temporary, snapshot, 'utf8');
    try {
      await fs.promises.rename(temporary, ATTEMPTS_PATH);
    } catch (error) {
      if (error.code !== 'EPERM' && error.code !== 'EEXIST') throw error;
      await fs.promises.writeFile(ATTEMPTS_PATH, snapshot, 'utf8');
      await fs.promises.rm(temporary, { force: true });
    }
  });
  return writeQueue;
}

function hash(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function secureShuffle(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = crypto.randomInt(index + 1);
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

function selectQuestionIds() {
  const eligible = bankDocument.question_bank.filter((question) =>
    ['single', 'multi', 'image'].includes(question.type)
  );
  const selected = [];
  for (const [category, count] of Object.entries(CATEGORY_QUOTAS)) {
    const categoryQuestions = secureShuffle(eligible.filter((question) => question.category === category));
    if (categoryQuestions.length < count) throw new Error(`Not enough ${category} questions`);
    selected.push(...categoryQuestions.slice(0, count));
  }
  return secureShuffle(selected).map((question) => question.id);
}

function publicQuestion(question) {
  return {
    id: question.id,
    type: question.type,
    category: question.category,
    difficulty: question.difficulty,
    question: question.question,
    options: secureShuffle(question.options).map((option) => ({ id: option.id, text: option.text })),
    selectionCount: question.type === 'multi' ? 3 : 1,
    image: question.image ? `/images/${encodeURIComponent(question.image)}` : null,
  };
}

function parseCookies(request) {
  return Object.fromEntries(
    String(request.headers.cookie || '')
      .split(';')
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => {
        const separator = part.indexOf('=');
        return separator < 0 ? [part, ''] : [part.slice(0, separator), decodeURIComponent(part.slice(separator + 1))];
      })
  );
}

function findAttempt(request) {
  const token = parseCookies(request).veer_attempt;
  if (!token) return null;
  const tokenHash = hash(token);
  return attempts.find((attempt) => attempt.tokenHash === tokenHash) || null;
}

function remainingSeconds(attempt) {
  return Math.max(0, Math.ceil((new Date(attempt.expiresAt).getTime() - Date.now()) / 1000));
}

function candidateKey(candidate) {
  return hash(`${candidate.email.trim().toLowerCase()}|${candidate.name.trim().toLowerCase()}`);
}

function json(response, status, body, extraHeaders = {}) {
  const payload = Buffer.from(JSON.stringify(body));
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': payload.length,
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  response.end(payload);
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    request.setEncoding('utf8');
    request.on('data', (chunk) => {
      body += chunk;
      if (body.length > 32_000) reject(new Error('Request too large'));
    });
    request.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('Invalid JSON')); }
    });
    request.on('error', reject);
  });
}

function validateOrigin(request) {
  const origin = request.headers.origin;
  if (!origin) return true;
  const host = request.headers.host;
  return origin === `http://${host}` || origin === `https://${host}`;
}

function finalizeAttempt(attempt, reason) {
  if (attempt.status === 'completed') return attempt.result;
  let points = 0;
  for (const questionId of attempt.questionIds) {
    const question = questionsById.get(questionId);
    const submitted = new Set(attempt.answers[questionId] || []);
    const correct = new Set(question.correct_answer_ids);
    if (question.type === 'multi') {
      points += [...submitted].filter((answerId) => correct.has(answerId)).length / 3;
    } else if (submitted.size === 1 && [...submitted].every((answerId) => correct.has(answerId))) {
      points += 1;
    }
  }
  const percentage = Math.round((points / QUESTION_COUNT) * 100);
  const answered = Object.keys(attempt.answers).length;
  const outcome = percentage >= 80 ? 'pass' : percentage >= 70 ? 'fair' : 'not-passed';
  attempt.status = 'completed';
  attempt.completedAt = new Date().toISOString();
  attempt.result = { percentage, points: Number(points.toFixed(2)), answered, total: QUESTION_COUNT, outcome, reason };
  persistAttempts();
  return attempt.result;
}

async function apiHandler(request, response, url) {
  if (!validateOrigin(request)) return json(response, 403, { error: 'Invalid request origin.' });

  if (request.method === 'POST' && url.pathname === '/api/assessment/start') {
    const body = await readJson(request);
    const name = String(body.name || '').trim().replace(/\s+/g, ' ');
    const email = String(body.email || '').trim().toLowerCase();
    if (!body.accepted || name.length < 2 || !/^\S+@\S+\.\S+$/.test(email)) {
      return json(response, 400, { error: 'Enter your name and a valid email, then accept the assessment terms.' });
    }
    const key = candidateKey({ name, email });
    const cooldownMs = COOLDOWN_DAYS * 24 * 60 * 60 * 1000;
    const prior = attempts.find((attempt) => attempt.candidateKey === key && attempt.status === 'completed' && Date.now() - new Date(attempt.completedAt).getTime() < cooldownMs);
    if (prior) {
      const availableAt = new Date(new Date(prior.completedAt).getTime() + cooldownMs).toISOString();
      return json(response, 409, { error: 'An assessment has already been completed for this candidate.', availableAt });
    }
    attempts = attempts.filter((attempt) => attempt.status === 'completed' || new Date(attempt.expiresAt).getTime() > Date.now());
    const token = crypto.randomBytes(32).toString('base64url');
    const now = new Date();
    const attempt = {
      id: crypto.randomUUID(), tokenHash: hash(token), candidateKey: key, candidate: { name, email },
      questionIds: selectQuestionIds(), answers: {}, currentIndex: 0, status: 'active',
      startedAt: now.toISOString(), expiresAt: new Date(now.getTime() + DURATION_SECONDS * 1000).toISOString(),
    };
    attempts.push(attempt);
    await persistAttempts();
    return json(response, 201, {
      question: publicQuestion(questionsById.get(attempt.questionIds[0])),
      current: 1, total: QUESTION_COUNT, remainingSeconds: DURATION_SECONDS,
    }, { 'Set-Cookie': `veer_attempt=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=172800` });
  }

  const attempt = findAttempt(request);
  if (!attempt) return json(response, 401, { error: 'No active assessment session.' });
  if (attempt.status === 'active' && remainingSeconds(attempt) === 0) finalizeAttempt(attempt, 'time-expired');

  if (request.method === 'GET' && url.pathname === '/api/assessment/state') {
    if (attempt.status === 'completed') return json(response, 200, { completed: true, result: attempt.result });
    return json(response, 200, {
      completed: false,
      question: publicQuestion(questionsById.get(attempt.questionIds[attempt.currentIndex])),
      current: attempt.currentIndex + 1, total: QUESTION_COUNT, remainingSeconds: remainingSeconds(attempt),
    });
  }

  if (request.method === 'POST' && url.pathname === '/api/assessment/answer') {
    if (attempt.status !== 'active') return json(response, 409, { completed: true, result: attempt.result });
    const body = await readJson(request);
    const expectedId = attempt.questionIds[attempt.currentIndex];
    const question = questionsById.get(expectedId);
    const answerIds = Array.isArray(body.answerIds) ? [...new Set(body.answerIds.map(String))] : [];
    const allowed = new Set(question.options.map((option) => option.id));
    const required = question.type === 'multi' ? 3 : 1;
    if (body.questionId !== expectedId || answerIds.length !== required || !answerIds.every((id) => allowed.has(id))) {
      return json(response, 400, { error: `Select exactly ${required} valid answer${required === 1 ? '' : 's'} before continuing.` });
    }
    attempt.answers[expectedId] = answerIds;
    attempt.currentIndex += 1;
    await persistAttempts();
    if (attempt.currentIndex >= QUESTION_COUNT) {
      return json(response, 200, { readyToSubmit: true, current: QUESTION_COUNT, total: QUESTION_COUNT, remainingSeconds: remainingSeconds(attempt) });
    }
    return json(response, 200, {
      question: publicQuestion(questionsById.get(attempt.questionIds[attempt.currentIndex])),
      current: attempt.currentIndex + 1, total: QUESTION_COUNT, remainingSeconds: remainingSeconds(attempt),
    });
  }

  if (request.method === 'POST' && url.pathname === '/api/assessment/submit') {
    const result = finalizeAttempt(attempt, remainingSeconds(attempt) === 0 ? 'time-expired' : 'candidate-submitted');
    return json(response, 200, { result });
  }

  if (request.method === 'GET' && url.pathname === '/api/assessment/result') {
    if (attempt.status !== 'completed') return json(response, 409, { error: 'Assessment is still in progress.' });
    return json(response, 200, { candidate: { name: attempt.candidate.name }, result: attempt.result });
  }

  return json(response, 404, { error: 'Not found.' });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };

function staticHandler(request, response, url) {
  const requested = url.pathname === '/' ? '/ai-skill-test.html' : url.pathname;
  if (requested === '/ai-skill-test.html') {
    response.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  }
  const safePath = path.normalize(decodeURIComponent(requested)).replace(/^(\.\.[/\\])+/, '');
  const filePath = path.join(PUBLIC_DIR, safePath);
  if (!filePath.startsWith(PUBLIC_DIR)) return json(response, 403, { error: 'Forbidden.' });
  fs.readFile(filePath, (error, data) => {
    if (error) return json(response, 404, { error: 'Not found.' });
    const extension = path.extname(filePath).toLowerCase();
    const headers = {
      'Content-Type': MIME[extension] || 'application/octet-stream',
      'Cache-Control': extension === '.html' ? 'no-cache' : 'public, max-age=86400',
    };
    if (['.html', '.css', '.js'].includes(extension) && /gzip/.test(request.headers['accept-encoding'] || '')) {
      const compressed = zlib.gzipSync(data);
      response.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': compressed.length, Vary: 'Accept-Encoding' });
      return response.end(compressed);
    }
    response.writeHead(200, { ...headers, 'Content-Length': data.length });
    response.end(data);
  });
}

const server = http.createServer((request, response) => {
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
  response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
  const handler = url.pathname.startsWith('/api/') ? apiHandler : staticHandler;
  Promise.resolve(handler(request, response, url)).catch((error) => {
    console.error(error);
    if (!response.headersSent) json(response, 500, { error: 'The assessment service encountered an error.' });
    else response.end();
  });
});

server.listen(PORT, () => console.log(`VEER assessment running at http://localhost:${PORT}`));
