'use strict';

document.addEventListener('DOMContentLoaded', loadResult);

async function loadResult() {
  const errorElement = document.getElementById('resultError');
  try {
    const response = await fetch('/api/assessment/result', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Your result could not be loaded.');
    renderResult(data);
  } catch (error) {
    document.getElementById('resultSpinner').classList.add('hidden');
    document.getElementById('resultEyebrow').textContent = 'Result unavailable';
    document.getElementById('resultTitle').textContent = 'We could not retrieve your result';
    document.getElementById('resultLead').textContent = 'Your attempt may still be securely recorded.';
    errorElement.textContent = `${error.message} Please return using the same browser or contact VEER support.`;
  }
}

function renderResult(data) {
  const { result, candidate } = data;
  const labels = { pass: 'Pass', fair: 'Fair pass', 'not-passed': 'Not passed' };
  const messages = {
    pass: {
      title: `Strong result, ${firstName(candidate.name)}.`,
      lead: 'You have demonstrated a strong foundation across the assessed AI competencies.',
      heading: 'What happens next',
      text: 'Your result has been recorded. VEER will review your assessment alongside your candidate profile and contact you about the next stage.',
    },
    fair: {
      title: `Assessment complete, ${firstName(candidate.name)}.`,
      lead: 'Your result meets the fair-pass band and will be reviewed with your wider candidate profile.',
      heading: 'What happens next',
      text: 'VEER will consider your assessment and submitted experience together before confirming whether you progress.',
    },
    'not-passed': {
      title: `Thank you for completing the assessment, ${firstName(candidate.name)}.`,
      lead: 'Your score did not reach the current progression threshold on this attempt.',
      heading: 'Your next opportunity',
      text: 'This result does not define your potential. You can strengthen the assessed areas and become eligible for another attempt after the assessment cooldown.',
    },
  };
  const copy = messages[result.outcome];
  document.getElementById('resultSpinner').classList.add('hidden');
  document.getElementById('resultEyebrow').textContent = result.reason === 'time-expired' ? 'Time ended · Result recorded' : 'Assessment complete';
  document.getElementById('resultTitle').textContent = copy.title;
  document.getElementById('resultLead').textContent = copy.lead;
  document.getElementById('resultScore').textContent = `${result.percentage}%`;
  document.getElementById('scoreOrbit').classList.add(result.outcome);
  document.getElementById('resultPoints').textContent = `${result.points} / ${result.total}`;
  document.getElementById('resultAnswered').textContent = `${result.answered} / ${result.total}`;
  document.getElementById('resultOutcome').textContent = labels[result.outcome];
  document.getElementById('nextStep').innerHTML = `<h2>${escapeHtml(copy.heading)}</h2><p>${escapeHtml(copy.text)}</p>`;
  document.getElementById('resultContent').classList.remove('hidden');
}

function firstName(name) {
  return String(name || 'Candidate').trim().split(/\s+/)[0];
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}
