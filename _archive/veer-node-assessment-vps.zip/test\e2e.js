'use strict';

const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const attemptsPath = path.join(root, 'data', 'attempts.test.json');
const port = 3011;
const base = `http://127.0.0.1:${port}`;
let cookie = '';

async function api(route, options = {}) {
  const response = await fetch(`${base}${route}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...(options.headers || {}) },
  });
  const setCookie = response.headers.get('set-cookie');
  if (setCookie) cookie = setCookie.split(';')[0];
  const body = await response.json();
  if (!response.ok) throw new Error(`${response.status} ${JSON.stringify(body)}`);
  return body;
}

async function run() {
  fs.writeFileSync(attemptsPath, '[]\n');
  const child = spawn(process.execPath, ['server.js'], {
    cwd: root,
    env: { ...process.env, PORT: String(port), ATTEMPTS_PATH: attemptsPath },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let errors = '';
  child.stderr.on('data', (chunk) => { errors += chunk; process.stderr.write(chunk); });
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Server did not start')), 5000);
      child.stdout.on('data', () => { clearTimeout(timer); resolve(); });
      child.once('exit', (code) => reject(new Error(`Server exited ${code}: ${errors}`)));
    });

    let state = await api('/api/assessment/start', {
      method: 'POST',
      body: JSON.stringify({ name: 'Automated QA Candidate', email: 'qa@example.test', accepted: true }),
    });
    const questionIds = new Set();
    for (let number = 1; number <= 35; number += 1) {
      const question = state.question;
      if (!question || question.correct_answer_ids || question.rationale) throw new Error('Private answer data exposed');
      questionIds.add(question.id);
      state = await api('/api/assessment/answer', {
        method: 'POST',
        body: JSON.stringify({ questionId: question.id, answerIds: question.options.slice(0, question.selectionCount).map((option) => option.id) }),
      });
    }
    await api('/api/assessment/submit', { method: 'POST', body: '{}' });
    const result = await api('/api/assessment/result');
    if (questionIds.size !== 35 || result.result.total !== 35 || result.result.answered !== 35) throw new Error('Assessment totals failed');
    process.stdout.write(JSON.stringify({
      uniqueQuestions: questionIds.size,
      total: result.result.total,
      answered: result.result.answered,
      privateAnswersExposed: false,
      resultReturned: true,
    }, null, 2));
  } finally {
    child.kill();
    fs.rmSync(attemptsPath, { force: true });
  }
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
